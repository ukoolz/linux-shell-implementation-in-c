/*
Name       : Dibyendu Das
Roll       : 14CS60R34
Assignment : 2
Part       : 2
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#define BUFFER_SIZE 200
//#define DEBUG

void execute_command(char *command, char *options, char *argument, bool read_input_from_stdin, char *buffer) {
  int nbytes, from_child[2], to_child[2], arg_index = 0;
  char *args[20] = {NULL}, *token;
  args[arg_index++] = command;
  token = strtok(options, " ");
  while(token) {
    args[arg_index] = (char *) malloc(strlen(token) + 1);
    strcpy(args[arg_index++], token);
    token = strtok(NULL, " ");
  }
  token = strtok(argument, " ");
  while(token) {
    args[arg_index] = (char *) malloc(strlen(token) + 1);
    strcpy(args[arg_index++], token);
    token = strtok(NULL, " ");
  }

  pipe(to_child);
  pipe(from_child);

  if(!fork()) {
      close(to_child[1]);              // Close the write descriptor of the pipe to_child
      close(from_child[0]);            // Close the read descriptor of the pipe from_child
      /*
      Leave the STDIN open if the flag read_input_from_stdin is set.
      Redirect everything that comes to the pipe to_child[0] (read descriptor) to STDIN otherwise.
      */
      if(!read_input_from_stdin) {
        close(0);
        dup(to_child[0]);
      }
      close(1);                        // Close the file descriptor STDOUT
      dup(from_child[1]);              // Redirect STDOUT to the write descriptor of the from_child pipe & send output to the parent
      execvp(args[0], args);
    } else {
      close(to_child[0]);              // Close the read descriptor of the pipe to_child
      close(from_child[1]);            // Close the write descriptor of the pipe from_child
      if(!read_input_from_stdin) {
        nbytes = write(to_child[1], buffer, strlen(buffer));
        close(to_child[1]);
        #ifdef DEBUG
        printf("==== parent wrote %d bytes of following data to child ====\n%s\
==========================================================\n", nbytes, buffer);
        #endif /* DEBUG */
      }
      nbytes = read(from_child[0], buffer, BUFFER_SIZE);
      buffer[nbytes] = '\0';
      #ifdef DEBUG
      printf("==== child executed '%s' & returned %d bytes of following data to parent ====\n%s\
=============================================================================\n", command, nbytes, buffer);
      #endif /* DEBUG */
      wait(NULL);
    }
  return;
}

char *my_pwd(void) {
  return (char *) get_current_dir_name();
}

void parse_input(char *input, int *argc, char **argv) {
  char new_line = '\0';
  int start, index;
  start = index = *argc = 0;
  printf("%s=> ", my_pwd());
  scanf("%1023[^\n]%c", input, &new_line);
  if(!strlen(input) && (new_line == '\n' || !new_line)) {
    getchar();
    return;
  }
  while(input[index]) {
    switch (input[index]) {
      case ' ':
        if(input[index-1] == '\\')
          break;
        else if(input[index-1] == ' ' || input[index-1] == '\t' || input[index-1] == '|' || input[index-1] == '>' || input[index-1] == '<') {
          start = index;
          break;
        }
	argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	strncpy(argv[*argc], input + start, index - start);
        start = index + 1;
        break;
      case '\t':
        if(input[index-1] == ' ' || input[index-1] == '\t' || input[index-1] == '|' || input[index-1] == '>' || input[index-1] == '<') {
          start = index;
          break;
        }
        argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	strncpy(argv[*argc], input + start, index - start);
        start = index + 1;
        break;
      case '|':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], "|");
        start = index + 1;
        break;
      case '>':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], ">");
        start = index + 1;
        break;
      case '<':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], "<");
        start = index + 1;
        break;
      case '-':
        if(input[index-1] == ' ' || input[index-1] == '\t')
          start = index;
        break;
      default :
        if((input[index-1] == ' ' || input[index-1] == '\t') && input[index-2] != '\\')
          start = index;
        break;
    }
    index++;
  }
  if(input[index-1] != ' ' && input[index-1] != '\t') {
    argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
    strncpy(argv[*argc], input + start, index - start);
    (*argc)++;
  }
  return;
}

int main() {
  char input_stream[1024], **argv = (char **) malloc(100 * sizeof(char *));
  int argc;

  while(true) {
    const char *executable, *input = NULL, *output = NULL;
    int i, index = 0;
    struct stat st;
    FILE *fp;
    char *buffer = NULL, argument[100] = {'\0'}, options[10] = {'\0'};

    memcpy(input_stream, (char [1024]){'\0'}, 1024);
    memcpy(argv, (char *[100]){NULL}, 100);
    parse_input(input_stream, &argc, argv);
    if(!argc)
      continue;
    
    executable = argv[1];
    for (i = 2; i < argc; i++) {
      if(!strcmp(argv[i], "<") || !strcmp(argv[i], "\\<")) {
        if(i == argc -1 || !strcmp(argv[i+1], ">") || !strcmp(argv[i+1], "\\>")) {
          printf("Syntax error near '<', expected filename");
          exit(0);
        }
        else {
          input = argv[++i];
          continue;
        }
      }
      else if(!strcmp(argv[i], ">") || !strcmp(argv[i], "\\>")) {
        if(i == argc -1 || !strcmp(argv[i+1], "<") || !strcmp(argv[i+1], "\\<")) {
          printf("Syntax error near '>', expected filename");
          exit(0);
        }
        else {
          output = argv[++i];
          continue;
        }
      }
      else if(argv[i][0] == '-')
        strcat(strcat(options, argv[i]), " ");
      else
        strcat(strcat(argument, argv[i]), " ");
    }

    options[strlen(options) - 1] = argument[strlen(argument) - 1] = '\0';
    #ifdef DEBUG
    printf("command = %s options = %s argument = %s input = %s output = %s\n", executable, options, argument, input, output);
    #endif /* DEBUG */

    if (input) {
      fp = fopen(input, "rt");
      if (!fp) {
        printf("Could not open input file : %s\n", input);
        exit(0);
      }
      stat (input, &st);
      buffer = (char *) malloc((st.st_size + 1) * sizeof (char));
      while (!feof(fp))
        *(buffer + index++) = fgetc(fp);
      fclose(fp);
      *(buffer + --index) = '\0';
    }

    buffer = input ? buffer : (char *) calloc(BUFFER_SIZE, 1);
    execute_command(executable, options, argument, input ? false : true, buffer);

    #ifdef DEBUG
    printf("======== final output ========\n");
    #endif /* DEBUG */
    fprintf(output ? (fp = fopen(output, "w")) : stdout, "%s", buffer);
    if (output)
      fclose(fp);
    free(buffer);

    for(i = 1; i < argc; i++)
      free(argv[i]);
  }
  free(argv);
  return 0;
}
