/*
Name       : Dibyendu Das
Roll       : 14CS60R34
Assignment : 2
Part       : 1
*/

#define _XOPEN_SOURCE 500
#define _SVID_SOURCE

#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ftw.h>
#include <dirent.h>

const char *DEST_FILE_BASE_PATH;
int SRC_FILE_BASE_PATH_LEN;
struct FTW;

int rm_callback(const char *file_path, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
  remove(file_path);
  return 0;
}

void copy_file(const char *src, const char *dest) {
  char ch, *dest_file_name = malloc(strlen(src) + strlen(dest) + 1);
  FILE *s = fopen(src, "rb"), *d;
  strcpy(dest_file_name, dest);
  strcat(dest_file_name, src + SRC_FILE_BASE_PATH_LEN);
  d = fopen(dest_file_name, "wb");
  while(( ch = fgetc(s)) != EOF)
    fputc(ch, d);
  fclose(s);
  fclose(d);
  free(dest_file_name);
  return;
}

int cp_callback(const char *file_path, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
  struct stat statbuf; 
  char *dest_dir_path = malloc(strlen(file_path) + strlen(DEST_FILE_BASE_PATH) + 1);
  strcpy(dest_dir_path, DEST_FILE_BASE_PATH);
  strcat(dest_dir_path, file_path + SRC_FILE_BASE_PATH_LEN);
  stat(file_path, &statbuf);
  if(S_ISDIR(statbuf.st_mode))
    mkdir(dest_dir_path, S_IRWXU | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
  else
    copy_file(file_path, DEST_FILE_BASE_PATH);
  free(dest_dir_path);
  return 0;
}

void copy_dir(const char *src, const char *dest) {
  char *loc = strrchr(src,'/');
  DEST_FILE_BASE_PATH = dest;
  SRC_FILE_BASE_PATH_LEN = loc == NULL ? 0 : (strlen(src) - strlen(loc) + 1);
  nftw(src, cp_callback, 10, 0);
  return;
}

static int one (const struct dirent *unused) {
  return 1;
}

void my_mkdir(int argc, const char **argv) {
  int i;
  for(i = 0; i < argc; i++)
      mkdir(argv[i], S_IRWXU | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
  return;
}

void my_rm(int argc, const char **argv) {
  int i;
  for(i = (argv[0][0] == '-') ? 1 : 0; i < argc; i++) {
    if(remove(argv[i]) == -1 && !strcmp("-r", argv[0])) {
      nftw(argv[i], rm_callback, 10, FTW_DEPTH);
      remove(argv[i]);
    }
  }
  return;
}

void my_cp(int argc, char **argv) {
  int i, recursive = !strcmp("-r", argv[0]);
  struct stat statbuf;
  if (argv[argc-1][strlen(argv[argc-1]) - 1] != '/')
    strcat(argv[argc-1], "/");
  for(i = argv[0][0] == '-' ? 1 : 0; i < argc - 1; i++) {
    stat(argv[i], &statbuf);
    if(S_ISDIR(statbuf.st_mode)) {
      if (recursive)
        copy_dir(argv[i], argv[argc-1]);
      else
        printf("cp: omitting directory '%s'\n", argv[i]);
    } else {
      SRC_FILE_BASE_PATH_LEN = strrchr(argv[i],'/') == NULL ? 0 : (strlen(argv[i]) - strlen(strrchr(argv[i],'/')) + 1);
      copy_file(argv[i], argv[argc-1]);
    }
  }
  return;
}

void my_ls(const char *path) {
  struct dirent **eps;
  int i, n = scandir(path ? path : ".", &eps, one, alphasort);
  if (n >= 0)
    for (i = 0; i < n; ++i)
      puts(eps[i]->d_name);
  else
    printf("couldn't open the directory : %s\n", path);
  return;
}

char *my_pwd(void) {
  return (char *) get_current_dir_name();
}

void my_cd(const char *path) {
  chdir(path);
  return;
}

void parse_input(char *input, int *argc, char **argv) {
  char new_line = '\0';
  int start, index;
  start = index = *argc = 0;
  printf("%s=> ", my_pwd());
  scanf("%1023[^\n]%c", input, &new_line);
  if(!strlen(input) && (new_line == '\n' || !new_line)) {
    getchar();
    return;
  }
  while(input[index]) {
    switch (input[index]) {
      case ' ':
        if(input[index-1] == '\\')
          break;
        else if(input[index-1] == ' ' || input[index-1] == '\t' || input[index-1] == '|' || input[index-1] == '>' || input[index-1] == '<') {
          start = index;
          break;
        }
	argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	strncpy(argv[*argc], input + start, index - start);
        start = index + 1;
        break;
      case '\t':
        if(input[index-1] == ' ' || input[index-1] == '\t' || input[index-1] == '|' || input[index-1] == '>' || input[index-1] == '<') {
          start = index;
          break;
        }
        argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	strncpy(argv[*argc], input + start, index - start);
        start = index + 1;
        break;
      case '|':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], "|");
        start = index + 1;
        break;
      case '>':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], ">");
        start = index + 1;
        break;
      case '<':
        if(input[index-1] != ' ' && input[index-1] != '\t') {
          argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
	  strncpy(argv[*argc], input + start, index - start);
        }
        argv[++(*argc)] = (char *) calloc(2, 1);
	strcpy(argv[*argc], "<");
        start = index + 1;
        break;
      case '-':
        if(input[index-1] == ' ' || input[index-1] == '\t')
          start = index;
        break;
      default :
        if((input[index-1] == ' ' || input[index-1] == '\t') && input[index-2] != '\\')
          start = index;
        break;
    }
    index++;
  }
  if(input[index-1] != ' ' && input[index-1] != '\t') {
    argv[++(*argc)] = (char *) calloc(index - start + 1, 1);
    strncpy(argv[*argc], input + start, index - start);
    (*argc)++;
  }
  return;
}

int main() {
  int argc;
  char input_stream[1024], **argv = (char **) malloc(100 * sizeof(char *));
  while(true) {
    int i;

    memcpy(input_stream, (char [1024]){'\0'}, 1024);
    memcpy(argv, (char *[100]){NULL}, 100);
    parse_input(input_stream, &argc, argv);
    if(!argc)
      continue;

    if(!strcmp("mkdir", argv[1]))
      my_mkdir(argc - 2, (const char **)(argv + 2));
    else if(!strcmp("cd", argv[1]))
      my_cd((const char *)argv[2]);
    else if(!strcmp("rm", argv[1]))
      my_rm(argc - 2, (const char **)(argv + 2));
    else if(!strcmp("mv", argv[1]))
      rename(argv[2], argv[3]);
    else if(!strcmp("cp", argv[1]))
      my_cp(argc - 2, argv + 2);
    else if(!strcmp("ls", argv[1]))
      my_ls(argv[2]);
    else if(!strcmp("pwd", argv[1]))
      printf("%s\n", my_pwd());
    else
      printf("Usage: command should be one of the following : mkdir, cd, rm, mv, cp, ls & pwd\n");

    for(i = 1; i < argc; i++)
      free(argv[i]);
  }
  free(argv);
  return 0;
}
